//
//  AGWebViewController.m
//  HomeWork Lesson 39 (UIWebView)
//
//  Created by Anton Gorlov on 21.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGWebViewController.h"
@interface AGWebViewController ()

@end

@implementation AGWebViewController 

- (void) viewDidLoad {
    [super viewDidLoad];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
    [self.webView loadRequest:request];

}

#pragma Mark -UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {

   // [self.indicatorView startAnimating];
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES; //indicator

}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    
   // [self.indicatorView stopAnimating];
    
     [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [self visibleButtons];

}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {

 //   [self.indicatorView stopAnimating];
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [self visibleButtons];
    
    if (error) {
        
        NSLog(@"Error %@",[error localizedDescription]);
    }
}

#pragma Mark -Methods

- (void) visibleButtons {

    self.backBarButtonItem.enabled = [self.webView canGoBack];
    self.forwardBarButtonItem.enabled = [self.webView canGoForward];
        
}

#pragma Mark - Actions

- (IBAction)actionBack:(UIBarButtonItem *)sender {
    
    if ([self.webView canGoBack]) {
        
        [self.webView stopLoading];
        [self.webView goBack];
    }
}

- (IBAction)actionForward:(UIBarButtonItem *)sender {
    
    if ([self.webView canGoForward]) {
        
        [self.webView stopLoading];
        [self.webView goForward];
        
    }
}

- (IBAction)actionRefresh:(UIBarButtonItem *)sender {
    
    [self.webView stopLoading];
    [self.webView reload];
}

- (IBAction)actionStop:(UIBarButtonItem *)sender {
    
    [self.webView stopLoading];
}
@end
