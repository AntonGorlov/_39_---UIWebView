//
//  AGViewController.m
//  HomeWork Lesson 39 (UIWebView)
//
//  Created by Anton Gorlov on 23.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGViewController.h"
#import "AGWebViewController.h"

@interface UITableViewController ()  <UITableViewDelegate, UITableViewDataSource>


@end

@implementation AGViewController


- (void)viewDidLoad {
    
     [super viewDidLoad];
    
    self.navigationItem.title = @"This is the list for you";
    
    [self insetStatusBar];
    
    [self webLinks];
    [self pdfFile];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    
    return 2;
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return @"URL";
        
    }else {
        
        return @"Pdf file";
    }
    
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (section == 0) {
        
        return [self.urlArray count];
        
    }else {
        
        return [self.pdfArray count];
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *identifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        
        if (indexPath.section == 0) {
            
            cell.textLabel.text = [self.urlArray objectAtIndex:indexPath.row];
            
        }else {
            
            cell.textLabel.text = [self.pdfArray objectAtIndex:indexPath.row];
        }
    }
    return cell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { //делаем действие
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //UIStoryboard *storyboard = self.storyboard;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    AGWebViewController *webController = [storyboard instantiateViewControllerWithIdentifier:@"AGWebViewController"];
 
    if (indexPath.section == 0) {
        
        webController.url = [NSURL URLWithString:[self.urlArray objectAtIndex:indexPath.row]];
        
    }else {
  
        webController.url = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:[self.pdfArray objectAtIndex:indexPath.row] ofType:nil]];
    }
    
   
   [self.navigationController pushViewController:webController animated:YES];
    
}

#pragma mark -Methods

- (void) insetStatusBar {
    
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 0, 0, 0);
    UIEdgeInsets inset2 = UIEdgeInsetsMake(0, 20, 0, 20);
    
    self.tableView.contentInset = inset;
    self.tableView.scrollIndicatorInsets = inset;
    self.tableView.separatorInset = inset2;
}

- (void) webLinks {
    
    NSString *googleLink =   @"http://www.google.com.ua";
    NSString *footballLink = @"http://www.football.ua";
    NSString *appleLink =    @"http://www.apple.com";
    NSString *vkLink =       @"http://www.vk.com";
    
    NSArray *urlArray = [NSArray arrayWithObjects:googleLink,footballLink,appleLink,vkLink ,nil];
    
    self.urlArray = urlArray;
    
    
}
- (void) pdfFile {
    
    NSString *atlantaPdfFile =  @"1.pdf";
    NSString *growPdfFile =     @"2.pdf";
    NSString *businessPdfFile = @"3.pdf";
    
    NSArray *pdfArray = @[atlantaPdfFile,growPdfFile,businessPdfFile];
    
    self.pdfArray = pdfArray;
    
}

@end
