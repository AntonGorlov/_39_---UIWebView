//
//  AppDelegate.h
//  HomeWork Lesson 39 (UIWebView)
//
//  Created by Anton Gorlov on 20.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

