//
//  AGViewController.h
//  HomeWork Lesson 39 (UIWebView)
//
//  Created by Anton Gorlov on 23.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGViewController : UITableViewController

@property (strong,nonatomic) NSArray * urlArray;
@property (strong,nonatomic) NSArray * pdfArray;


@end
