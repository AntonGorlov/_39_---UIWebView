//
//  AppDelegate.h
//  UIWebView (Lesson 39)
//
//  Created by Anton Gorlov on 18.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

