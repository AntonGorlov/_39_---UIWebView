//
//  ViewController.m
//  UIWebView (Lesson 39)
//
//  Created by Anton Gorlov on 18.06.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
     
     У WebView есть 3 способа загрузки контента:
     - (void)loadRequest:
     - (void)loadHTMLString:
     - (void)loadData:(NSData *)
     */
    
    //как сделать URLRequest? 3 способа:
    
    
    //1.1.)
    
    NSString *urlString = @"http://football.ua"; //соз url строку
    NSURL *url = [NSURL URLWithString:urlString]; //для запроса нужен url,соз его. NSURL есть: absoluteURL (обсолютный путь,http://адрес и т.д) и baseURL(когда уже какая-то часть base стоит)
    NSURLRequest *request = [NSURLRequest requestWithURL:url]; //соз запрос
    [self.webView loadRequest:request]; //загружаем запрос
    
    
    //2.)
    //WebView может загружать файлы (doc.exel,pdf,картинки и т.д)  //загрузим ресурс ,бросим в проект pdf.
  /*
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"1" ofType:@"pdf"]; //Берем путь нашего файла.Наше приложение это Bundle.Bundle - это папка нашего приложения(проекта),Bundle  говорит:дай-ка нам путь для ресурса с типом.Нужно брать pathForResource.Можно еще так писать pathForResource:@"1.pdf" ofType:@"nil"
   */
    /*
    NSData *fileData = [NSData dataWithContentsOfFile:filePath]; //У NSData есть этот метод.Нужно указать путь файла на компе
    
    [self.webView loadData:fileData //загружаем pdf через loadData (ЭТОТ СПОСОБ НЕ ОСОБО ЭФФЕКТИВНЫЙ, ТАК КАК В ДОКУМЕНТЕ ПРОПАДАЮТ ВНУТРЕННИЕ ССЫЛКИ)
                 MIMEType:@"application/pdf" //Xcode lолжен воспринимать ,что это за тип (тип Data) бинарная дата
         textEncodingName:@"UTF-8" //(энкодинг для текста (кодировка))
                   baseURL:nil];
    */
    /*
   //1.2.) (В ЭТОМ СПОСОБЕ РАБОТАЮТ И ВНУТРЕННИЕ И НАРУЖНЫЕ ССЫЛКИ В ДОКУМЕНТЕ)
    // filePath не коментируем,пробуем открыть через URL
    
    NSURL *fileUrl =[NSURL fileURLWithPath:filePath]; //указываем путь через Bundle.Чтобы посмотреть путь пишем в консоле "po filePath"
    NSURLRequest *request = [NSURLRequest requestWithURL:fileUrl];
    [self.webView loadRequest:request]; (webView уже ищет этот pdf через request)
    */
    
    //3.)
    //соз HTML строку
 /*
    NSString *htmlString = @"<html>"
                                "<body>"
    
                                    "<p style=\"font-size:500%%; text-align :center;\"> Hello</p>"
                                    "<br><a href=\"http://football.ua\"><b>football</b></a></br>" //соз ссылку
                                    "<a href=\"cmd:show_alert\">Test button</a>" //соз кнопку
                                "/<body>"
                            "/<html>";
    
    // "" разбивает строку на части (делает конкатанацию) конкатанация - операция склеивания обьектов
    
    [self.webView loadHTMLString:htmlString baseURL:nil];
  */
    
    //если запустим App,то Xcode будет пытаться загрузить эту ссылку в методе "shouldStartLoadWithRequest",но он не знает ,что с ней делать так как это не HTTP,HTTPS это наш собственный формат,Мы можем взять эту команду,этот URL!!!смотри в метод "shouldStartLoadWithRequest"
    
  
}

#pragma mark- UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {//метод говорит,должен ли я стартовать такой Request(Запрос)?Если будем пытаться загрузить какой-то Request во View,то сначала вызывается этот метод.NSURLRequest - это запрос на URL по какому-то адресу (это может быть адрес к файлу по локальной машине,либо к файлу интернета)

  //  NSLog(@"shouldStartLoadWithRequest %@",[request debugDescription]);
/*
    NSString *urlString = [request.URL absoluteString];//у request есть свойство URL,обсолютным путем
    
    if ([urlString hasPrefix:@"cmd:"]) {//если есть префикс "cmd:",это это означает,что это внутринняя команда,будем возвращать "NO"
        NSString *command = [urlString substringFromIndex:4]; // начинается с 4-х символов (0,1,2,3 с 4-го символа все строка)
        
        if ([command isEqualToString:@"show_alert"]) { //проверяем show_alert -это команда
            
            //соз алерт
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Hello.i'm an alert" message:@"What's new with you?" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Okаy" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {}];
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
            
            
        }
        return NO;
    }
    
*/
   
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView { //загружаем стартует Request
    
   
    [self yesButton];
    //[self.indicator startAnimating];
     [UIApplication sharedApplication].networkActivityIndicatorVisible = YES; //индикатор загрузки слева вверху
    NSLog(@"finish loading");
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView { //закончили загружать Request

    
    [self noButton];
   // [self.indicator stopAnimating];
     [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    NSLog(@"start loading");
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error { //ошибка

   // [self.indicator stopAnimating];
   
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
  //  NSLog(@"didFailLoadWithError %@",error);
    [self.indicator stopAnimating];
    [self noButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- Action
- (IBAction)backButtonAction:(UIBarButtonItem *)sender {
    
    if ([self.webView canGoBack]) { //если может идти назад,то
        
        [self.webView stopLoading];
        [self.webView goBack]; //идет назад
    }
    
}

- (IBAction)forwardButtonAction:(id)sender {
    
    if ([self.webView canGoForward]){
        
        [self.webView stopLoading];
        [self.webView goForward];
    }
    
}

- (IBAction)refreshButtonAction:(UIBarButtonItem *)sender {
    
    [self yesButton];
    [self.webView stopLoading];
    [self.webView reload]; //перезагрузка страницы
    
}

- (IBAction)stopLoadingButton:(UIBarButtonItem *)sender {
    
    [self.webView stopLoading];
}

#pragma mark- Methods

- (void) forwardAndBackButton {

    self.backButtonItem.enabled = [self.webView canGoBack]; //если можно идти назад,то будет "enabled",если нельзя-disable
    self.goButtonItem.enabled = [self.webView canGoForward];
    self.stopLoadingItem.enabled = [self.webView isLoading];
}

- (void) yesButton {
    
    if ([self.webView isLoading]) {
        
        
      //  self.refreshButtonItem.tintColor = [UIColor clearColor]; //прячем кнопку
        self.refreshButtonItem.enabled = NO; //нельзя нажать
        self.stopLoadingItem.enabled = YES;
    }
    
}

- (void) noButton {
    
   // self.stopLoadingItem.tintColor = [UIColor clearColor];
    self.stopLoadingItem.enabled = NO;
    
    [self.webView stopLoading];
   // self.refreshButtonItem.tintColor = [UIColor orangeColor];
    self.refreshButtonItem.enabled = YES;
    
}

@end
